from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """Class to access the Animals collection in the AAC database"""
    def __init__(self, username:str, password:str) -> None:
        # initialize connection without authentication
        self.client = MongoClient('mongodb://localhost:54685')
        # initialize connection with authentication
        # slef.client = MongoClient('mongodb://%s:%s@localhost:54685/?authMechanism=DEFAULT&authSource=AAC'%(username,password)
        self.database = self.client['AAC']


    def create(self, data:dict) -> bool:
        # data should be a dictionary corresponding to a MongoDB document
        if data is not None:
            self.database.animals.insert(data)
            return True
        else:
            raise Exception('No data suppled')
            return False


    def update_one_document(self, documentFind:dict, documentUpdate:dict): # -> bool:
        # find the documentFind document and update it with
        # the documentUpdate document, document can contain {'$set':{...}}
        # no return value - update_one() has complicated return vales
        if documentFind is not None and documentUpdate is not None:
            updateResult = self.database.animals.update_one(documentFind, documentUpdate)
        else:
            print('Either documentFind was empty, or documentUpdate was empty, or both were empty')
        if updateResult.modified_count == 1:
            print('Document updated')
            return True
        else:
            print('Document update failed')
            return False


    def delete_one_document(self, documentToDelete: dict) -> bool:
        # delete the record identified by the documentToDelete dictionary
        if documentToDelete is not None:
            deleteResults = self.database.animals.delete_one(documentToDelete)
            print(deleteResults.deleted_count)
            if deleteResults.deleted_count == 1:
                return True
            else:
                return False
        else:
            print('documentToDelete is empty')
            return False


    def read_all(self, data:dict): # -> pointer: don't know hot to specify a pointer to a cursor
        # return a cursor that points to the results
        if data is not None:
            return self.database.animals.find(data, {'_id':False})
        else:
            print('Nothing to read: query is empty')
            return None


    def read_one(self, data:dict) -> dict:
        # return a single document
        if data is not None:
            return self.database.animals.find_one(data)
        else:
            print('Nothing to read: query is empty')
            return None


